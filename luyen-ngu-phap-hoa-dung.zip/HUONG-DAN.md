# App Luyện Ngữ Pháp Hoa Dũng — Hướng dẫn đưa lên GitHub + Vercel

Trong file zip chỉ có **một file `index.html`** — đây là toàn bộ app (HTML, CSS, JavaScript, dữ liệu bài tập đều gộp sẵn trong một file, không cần cài thêm gì). Link Google Sheet lưu điểm học sinh cũng đã gắn sẵn trong file này.

## Bước 1. Đưa lên GitHub

1. Vào github.com, đăng nhập, bấm **New repository** (hoặc dấu +  góc trên bên phải → New repository).
2. Đặt tên repo, ví dụ `luyen-ngu-phap-hoa-dung`. Để **Public** hoặc **Private** đều được.
3. Không cần tick "Add README" — để trống rồi bấm **Create repository**.
4. Ở trang repo vừa tạo, bấm **uploading an existing file** (hoặc **Add file → Upload files**).
5. Kéo thả file `index.html` vào, bấm **Commit changes**.

## Bước 2. Deploy lên Vercel

1. Vào vercel.com, đăng nhập bằng tài khoản GitHub (nếu chưa có tài khoản thì bấm Sign Up → Continue with GitHub).
2. Bấm **Add New... → Project**.
3. Chọn repo `luyen-ngu-phap-hoa-dung` vừa tạo → bấm **Import**.
4. Vercel sẽ tự nhận đây là trang tĩnh (Other / Static), không cần chỉnh gì thêm — bấm **Deploy**.
5. Chờ khoảng 30 giây, Vercel đưa ra một đường link dạng `https://ten-du-an.vercel.app`. Đây là link học sinh dùng để làm bài.

## Sau khi deploy

- Mỗi lần Claude gửi thầy bản `index.html` mới (có thêm chủ đề, sửa lỗi...), thầy chỉ cần vào lại repo GitHub → **Add file → Upload files** → chọn file mới → Commit. Vercel tự động deploy lại link cũ, không cần làm lại bước 2.
- Link Vercel có thể đặt tên miền riêng (ví dụ noconggiasu.vn) trong phần **Settings → Domains** của dự án trên Vercel, nếu thầy có tên miền.
- Nếu muốn đổi link Google Sheets nhận điểm (ví dụ tạo sheet mới), báo Claude để build lại file `index.html` với link mới rồi gửi lại.

## Nội dung trong bản này

**Chuỗi bài: Thì hiện tại đơn** (học lần lượt từ bài 1, 15 chủ đề):
1. Starters 1 - Lesson 7: Đại từ nhân xưng (15 bài)
2. Starters 1 - Lesson 4: Danh từ số ít - số nhiều (15 bài)
3. E4 Tập 1 - Unit 1: Động từ to be (6 bài)
4-9. E3 Tập 2 - Unit 22 đến 27: Hiện tại đơn khẳng định, phủ định, nghi vấn; like/likes; don't/doesn't like; Do/Does + like (24 bài)
10-13. E4 Tập 1 - Unit 9 đến 12: Hiện tại đơn khẳng định, phủ định, câu hỏi Yes/No, câu hỏi What (19 bài)
14. Starters 2 - Lesson 13: Thì hiện tại đơn tổng hợp (15 bài)
15. Movers 2 - Lesson 11: Thì hiện tại đơn nâng cao (12 bài)
16. E5 Tập 1 - Unit 4: Hiện tại đơn luyện tổng hợp (6 bài)

**Chủ đề khác:** Movers 1 - Lesson 8: So sánh hơn - So sánh nhất (12 bài)

Lưu ý về đáp án: E4 Tập 1 và E5 Tập 1 trong bản PDF không có trang đáp án, nên đáp án các bài này do Claude soạn theo yêu cầu của thầy. Các cuốn còn lại chấm theo đúng trang đáp án in trong sách.

## Những phần chưa có trong bản này

- E5 Tập 1 Unit 4 Bài IV (much/many/a few/a little) chưa đưa vào vì không thuộc chủ điểm thì hiện tại đơn.
- Flyers 1 Lesson 8 (tổng hợp 6 thì) chưa đưa vào, chờ thầy quyết định.
- Các chủ đề ngữ pháp khác của 10 cuốn sẽ làm thêm theo đợt; mỗi đợt có file index.html mới để thầy upload đè lên GitHub.
