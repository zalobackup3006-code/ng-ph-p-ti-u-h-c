# App Luyện Ngữ Pháp Hoa Dũng — Hướng dẫn đưa lên GitHub + Vercel

Trong file zip chỉ có **một file `index.html`** — đây là toàn bộ app (HTML, CSS, JavaScript, dữ liệu bài tập đều gộp sẵn trong một file, không cần cài thêm gì). Link Google Sheet lưu điểm học sinh cũng đã gắn sẵn trong file này.

## Bước 1. Đưa lên GitHub

1. Vào github.com, đăng nhập, bấm **New repository** (hoặc dấu +  góc trên bên phải → New repository).
2. Đặt tên repo, ví dụ `luyen-ngu-phap-hoa-dung`. Để **Public** hoặc **Private** đều được.
3. Không cần tick "Add README" — để trống rồi bấm **Create repository**.
4. Ở trang repo vừa tạo, bấm **uploading an existing file** (hoặc **Add file → Upload files**).
5. Kéo thả file `index.html` vào, bấm **Commit changes**.

## Bước 2. Deploy lên Vercel

1. Vào vercel.com, đăng nhập bằng tài khoản GitHub (nếu chưa có tài khoản thì bấm Sign Up → Continue with GitHub).
2. Bấm **Add New... → Project**.
3. Chọn repo `luyen-ngu-phap-hoa-dung` vừa tạo → bấm **Import**.
4. Vercel sẽ tự nhận đây là trang tĩnh (Other / Static), không cần chỉnh gì thêm — bấm **Deploy**.
5. Chờ khoảng 30 giây, Vercel đưa ra một đường link dạng `https://ten-du-an.vercel.app`. Đây là link học sinh dùng để làm bài.

## Sau khi deploy

- Mỗi lần Claude gửi thầy bản `index.html` mới (có thêm chủ đề, sửa lỗi...), thầy chỉ cần vào lại repo GitHub → **Add file → Upload files** → chọn file mới → Commit. Vercel tự động deploy lại link cũ, không cần làm lại bước 2.
- Link Vercel có thể đặt tên miền riêng (ví dụ noconggiasu.vn) trong phần **Settings → Domains** của dự án trên Vercel, nếu thầy có tên miền.
- Nếu muốn đổi link Google Sheets nhận điểm (ví dụ tạo sheet mới), báo Claude để build lại file `index.html` với link mới rồi gửi lại.

## Những phần chưa có trong bản này

- Mới có 1 chủ đề: So sánh hơn — So sánh nhất (English Grammar for Movers 1, Lesson 8, 12 bài).
- Các chủ đề/cuốn khác sẽ làm thêm theo đợt, mỗi đợt Claude sẽ gửi lại file `index.html` mới để thầy upload đè lên GitHub.
